import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:social/data/models/user.dart';
import 'package:social/data/repo/firebase_auth_provider.dart';

import '../../../routes.dart';

part 'register_state.dart';

class RegisterCubit extends Cubit<RegisterState> {
  RegisterCubit() : super(RegisterInitial());

  static RegisterCubit get(context) => BlocProvider.of(context);

  Future register(
      {required String name,
      required String userName,
      required String password,
      required String email,
      required String phone,
      required BuildContext context}) async {
    Users user = Users(
      email: email,
      password: password,
      phone: phone,
      userName: userName,
    );
    emit(RegisterLoading());
    await FirebaseAuthRepository.register(user: user, then: () {})
        .then((value) {
      emit(RegisterSuccess());
      Navigator.pushReplacementNamed(context, Screens.homeScreen);
    }).catchError((error) => emit(RegisterError()));
  }
}
