import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:social/presentation/components/buttons.dart';
import 'package:social/presentation/components/general.dart';
import 'package:social/presentation/const.dart';
import 'package:social/presentation/screens/edit_profile_screen/edit_profile_cubit/edit_cubit.dart';

import '../../../const/Pallet.dart';
import '../../../const/strings.dart';
import '../../../data/models/user.dart';

class EditProfileScreen extends StatelessWidget {
  EditProfileScreen({Key? key}) : super(key: key);
  var nameController = TextEditingController();

  var bioController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          EditCubit()..getUser(bio: bioController, name: nameController),
      child: Scaffold(
        appBar: MyAppBar(title: 'Edit Profile'),
        body: BlocConsumer<EditCubit, EditState>(
          listener: (context, state) {
            // TODO: implement listener
          },
          builder: (context, state) {
            var cubit = EditCubit.get(context);
            Users currentUser = cubit.currentUser!;
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: Column(
                  children: [
                    Container(
                      height: 250,
                      child: Stack(
                          fit: StackFit.loose,
                          alignment: Alignment.bottomCenter,
                          children: [
                            Positioned(
                              bottom: 45,
                              top: 0,
                              // width: double.maxFinite,
                              left: 0,
                              right: 0,
                              child: Stack(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: NetworkImage(postPic),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      top: 10,
                                      right: 10,
                                      child: EditingButton()),
                                ],
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              child: Container(
                                height: 120,
                                width: 120,
                                child: Stack(
                                    alignment: Alignment.center,
                                    fit: StackFit.passthrough,
                                    children: [
                                      CircleAvatar(
                                        backgroundColor: Pallet.clearColor,
                                      ),
                                      Positioned(
                                        height: 115,
                                        width: 115,
                                        child: CircleClip(
                                          radius: 120,
                                          picture: profilePic,
                                        ),
                                      ),
                                      Positioned(
                                          bottom: 0,
                                          right: 0,
                                          child: EditingButton())
                                    ]),
                              ),
                            )
                          ]),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    Column(
                      children: [
                        Text(currentUser.userName!),
                        SizedBox(
                          height: 10,
                        ),
                        ProfileEditingTextField(
                            onChanged: (val) {
                              currentUser.userName = nameController.value.text;
                            },
                            bioController: nameController,
                            currentUser: currentUser),
                        SizedBox(
                          height: 25,
                        ),
                        ProfileEditingTextField(
                            bioController: bioController,
                            currentUser: currentUser),
                      ],
                    ),
                    SizedBox(
                      height: 155,
                    ),
                    AppFlatButton(
                        padding: 0,
                        width: double.infinity,
                        height: getHeight(context),
                        onPressed: () {},
                        title: 'Save')
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ProfileEditingTextField extends StatelessWidget {
  ProfileEditingTextField({
    Key? key,
    required this.bioController,
    required this.currentUser,
    this.onChanged,
  }) : super(key: key);

  final TextEditingController bioController;
  final Users currentUser;
  Function(String)? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: bioController,
      onChanged: onChanged,
      decoration: InputDecoration(
        border: OutlineInputBorder(),
      ),
    );
  }
}

class EditingButton extends StatelessWidget {
  const EditingButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipOval(
      child: Container(
        height: 35,
        width: 35,
        color: Pallet.mainColor,
        child: Center(
          child: IconButton(
            color: Pallet.clearColor,
            iconSize: 35,
            icon: Icon(
              Icons.edit,
              size: 17.5,
            ),
            onPressed: () {},
          ),
        ),
      ),
    );
  }
}
