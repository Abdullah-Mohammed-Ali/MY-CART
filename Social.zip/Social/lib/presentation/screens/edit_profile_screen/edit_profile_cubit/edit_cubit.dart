import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:social/data/repo/firebase_auth_provider.dart';

import '../../../../data/models/user.dart';

part 'edit_state.dart';

class EditCubit extends Cubit<EditState> {
  EditCubit() : super(EditInitial());

  static EditCubit get(context) => BlocProvider.of(context);

  Users? currentUser;

  Users? getUser({
    required TextEditingController bio,
    required TextEditingController name,
  }) {
    emit(EditLoading());
    if (FirebaseAuthRepository.userModel != null) {
      bio.text = FirebaseAuthRepository.userModel!.bio!;
      name.text = FirebaseAuthRepository.userModel!.userName!;

      currentUser = FirebaseAuthRepository.userModel;
      emit(EditSuccess());
      return currentUser;
    } else {
      emit(EditError());
    }
  }

  Future updateUser(context) async {
    emit(EditLoading());
    await FirebaseAuthRepository.updateUser(
      context: context,
      user: currentUser!,
    ).catchError((error) {
      emit(EditError());
    });
  }
}
