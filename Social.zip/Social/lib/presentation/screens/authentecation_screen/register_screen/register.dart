import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:social/buisness_logic/auth_cubit/register_cubit/register_cubit.dart';
import 'package:social/const/Pallet.dart';
import 'package:social/presentation/components/buttons.dart';
import 'package:social/presentation/components/general.dart';
import 'package:social/presentation/components/text_field.dart';

class RegisterScreen extends StatefulWidget {
  RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  var nameController = TextEditingController();

  var usernameController = TextEditingController();

  var phoneController = TextEditingController();

  var emailController = TextEditingController();

  var passController = TextEditingController();

  GlobalKey<FormState> textKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    SizedBox spacing({double val = 0.03}) => SizedBox(height: height * val);
    return BlocProvider(
      create: (context) => RegisterCubit(),
      child: BlocConsumer<RegisterCubit, RegisterState>(
        listener: (context, state) {
          if (state is RegisterLoading) {
            showDialog(context: context, builder: (_) => alertDialog);
          }
        },
        builder: (context, state) {
          var cubit = RegisterCubit.get(context);

          return Scaffold(
            backgroundColor: Pallet.clearColor,
            appBar: MyAppBar(
              title: 'Register',
            ),
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: textKey,
                  child: Column(
                    children: [
                      spacing(val: 0.06),
                      Text(
                          'Hey! We need few details from you before you start sharing on Momento'),
                      spacing(val: 0.06),
                      AppTextField(
                          emailController: nameController,
                          validator: (value) {
                            return validate(value: value!, hintText: 'Name');
                          },
                          title: 'Name'),
                      spacing(),
                      AppTextField(
                          emailController: usernameController,
                          validator: (value) {
                            return validate(
                                value: value!, hintText: 'Username');
                          },
                          title: 'Username'),
                      spacing(),
                      AppTextField(
                          emailController: phoneController,
                          validator: (value) {
                            return validate(value: value!, hintText: 'phone');
                          },
                          title: 'phone'),
                      spacing(),
                      AppTextField(
                          emailController: emailController,
                          validator: (value) {
                            return validate(value: value!, hintText: 'Email');
                          },
                          title: 'E-mail'),
                      spacing(),
                      AppTextField(
                          obscureText: true,
                          emailController: passController,
                          validator: (value) {
                            return validate(
                                value: value!, hintText: 'Password');
                          },
                          title: 'Password'),
                      spacing(val: 0.05),
                      AppFlatButton(
                          padding: 0,
                          width: width,
                          height: height,
                          onPressed: () async {
                            if (textKey.currentState!.validate()) {
                              await cubit.register(
                                  email: emailController.text,
                                  password: passController.text,
                                  phone: passController.text,
                                  userName: usernameController.text,
                                  name: nameController.text,
                                  context: context);
                            }
                          },
                          title: 'Register'),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

String? validate({required String value, required String hintText}) {
  if (value.isEmpty) {
    return 'please enter your $hintText';
  }
}
