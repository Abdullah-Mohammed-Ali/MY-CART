import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:social/presentation/screens/bottom_screens/settings_screen/setting_cubit/setting_cubit.dart';
import 'package:social/routes.dart';

import '../../../../const/Pallet.dart';
import '../../../../const/strings.dart';
import '../../../components/general.dart';

class SettingScreen extends StatelessWidget {
  const SettingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SettingCubit>(
      create: (context) => SettingCubit()..getUser(),
      child: Scaffold(
        body: BlocConsumer<SettingCubit, SettingState>(
          listener: (context, state) {
            // TODO: implement listener
          },
          builder: (context, state) {
            var cubit = SettingCubit.get(context);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Column(
                children: [
                  Container(
                    height: 250,
                    child: Stack(
                        fit: StackFit.loose,
                        alignment: Alignment.bottomCenter,
                        children: [
                          Positioned(
                            bottom: 45,
                            top: 0,
                            // width: double.maxFinite,
                            left: 0,
                            right: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: NetworkImage(postPic),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            child: Container(
                              height: 120,
                              width: 120,
                              child: Stack(
                                  alignment: Alignment.center,
                                  fit: StackFit.passthrough,
                                  children: [
                                    CircleAvatar(
                                      backgroundColor: Pallet.clearColor,
                                    ),
                                    Positioned(
                                      height: 115,
                                      width: 115,
                                      child: CircleClip(
                                        radius: 120,
                                        picture: cubit.currentUser!.image!,
                                      ),
                                    ),
                                  ]),
                            ),
                          )
                        ]),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  Column(
                    children: [
                      Text(cubit.currentUser!.userName!),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        cubit.currentUser!.bio!,
                        style: Theme.of(context)
                            .textTheme
                            .caption!
                            .copyWith(fontSize: 14),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Row(
                    children: [
                      ProfileInfoButton(),
                      ProfileInfoButton(),
                      ProfileInfoButton(),
                      ProfileInfoButton(),
                    ],
                  ),
                  Divider(
                    thickness: 1,
                  ),
                  Row(
                    children: [
                      Expanded(
                        flex: 4,
                        child: Container(
                          height: 50,
                          child: OutlinedButton(
                            style: ButtonStyle(
                              side: MaterialStateProperty.all(
                                BorderSide(color: Pallet.mainColor),
                              ),
                            ),
                            onPressed: () {},
                            child: Text(
                              'Add Photos',
                              style: TextStyle(color: Pallet.mainColor),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          height: 50,
                          child: OutlinedButton(
                            style: ButtonStyle(
                              side: MaterialStateProperty.all(
                                BorderSide(color: Pallet.mainColor),
                              ),
                            ),
                            onPressed: () {
                              Navigator.pushNamed(context, Screens.edit);
                            },
                            child: Icon(
                              Icons.edit,
                              color: Pallet.mainColor,
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class ProfileInfoButton extends StatelessWidget {
  const ProfileInfoButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: () {},
        child: SizedBox(
          height: 50,
          child: Column(
            children: [
              Text('100'),
              SizedBox(height: 12),
              Text(
                'Posts',
                style: Theme.of(context).textTheme.caption,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
