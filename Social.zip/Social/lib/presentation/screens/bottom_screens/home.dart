import 'package:flutter/material.dart';
import 'package:social/const/Pallet.dart';
import 'package:social/presentation/components/general.dart';
import 'package:social/presentation/screens/bottom_screens/settings_screen/setting.dart';
import 'package:social/presentation/screens/bottom_screens/users_screen/users.dart';

import 'chats_screen/chats.dart';
import 'feeds_screen/feeds_screen.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentIndex = 0;
  List<Widget> bottomScreens = const [
    FeedsScreen(),
    ChatsScreen(),
    UsersScreen(),
    SettingScreen(),
  ];

  List<String> titles = const ['New Feeds', 'Chats', 'Users', 'Settings'];

  var pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Pallet.clearColor,
        appBar: MyAppBar(title: titles[currentIndex]),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: currentIndex,
          onTap: (index) {
            setState(() {
              currentIndex = index;
              pageController.animateToPage(index,
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeInOutCubic);
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.message),
              label: 'Chats',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.location_on),
              label: 'Users',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
        body: PageView.builder(
          itemBuilder: (_, index) {
            return bottomScreens[index];
          },
          onPageChanged: (index) {
            setState(() {
              currentIndex = index;
            });
          },
          itemCount: bottomScreens.length,
          controller: pageController,
        ));
  }
}
