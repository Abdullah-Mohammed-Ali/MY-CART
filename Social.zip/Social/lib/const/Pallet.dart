import 'dart:ui';

class Pallet {
  static const Color mainColor = Color(0xFFFF6265);
  static const Color clearColor = Color(0xFFFFFFFF);
  static const Color ShadoIcon = Color(0xE98D8B8B);
  static const Color Shado = Color(0xA69C9A9A);
  static const Color regText = Color(0xF0000000);
}
