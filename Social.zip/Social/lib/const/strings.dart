const INTRO =
    'Momento is a social app that lets you share your moments with friends';
const uidKey = 'uID';
const profilePic =
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpO7apPJasmoSUBRN_0rSqbA4d9nCPlPm3EZehCWMbsU2kSZ7Y54-TY_4&s=10';
const postPic =
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLiDt3lCIYNIXKAOkdLsPnXgM620egW67IHQ&usqp=CAU';
